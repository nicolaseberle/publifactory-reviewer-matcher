import pickle
import logging
from elasticsearch import Elasticsearch
from gensim.similarities import Similarity

logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)

from model_scripts.requestsES import get_abstracts
from model_scripts.requestsES import get_abstract
from model_scripts.preprocess import getCorpus
from model_scripts.preprocess import preprocess
from model_scripts.lsi_model import updateModel

# REQUEST ES

df_temp = pickle.load(open("saves_test/dfES.p", "rb"))
print("Requests ES Done")

# PREPROCESS

corpus, index, dictionary, list_id = getCorpus(df_temp)
index = "saves_test/index"
print("Corpus Done")

# LSI Model

model = Similarity(index, corpus, num_features=len(dictionary), num_best=30)
print("Model Done")

# UPDATE LSI MODEL

# VALEUR QUI NE FONCTIONNE PAS
new_value = {
    "id": "XX-1",
    "title": "The article describes the control of the 2-axis electrohydraulic manipulator by the human-hand motion. To recognition of skeleton points the Kinect sensor was used. In this application the information about coordinates of shoulder, elbow and hand was used to compute of inverse kinematic in manipulator. In investigation the accuracy of control by human's hand motion was tested. The aim of study was to find a new of control method without commonly used joysticks to create human-machine interface.",
    "abstract": "In mammals, the PGC-1 transcriptional coactivators are key regulators of energy metabolism, including mitochondrial biogenesis and respiration, which have been implicated in numerous pathogenic conditions, including neurodegeneration and cardiomyopathy. Here, we show that overexpression of the Drosophila PGC-1 homolog (dPGC-1/spargel) is sufficient to increase mitochondrial activity. Moreover, tissue-specific overexpression of dPGC-1 in stem and progenitor cells within the digestive tract extends life span. Long-lived flies overexpressing dPGC-1 display a delay in the onset of aging-related changes in the intestine, leading to improved tissue homeostasis in old flies. Together, these results demonstrate that dPGC-1 can slow aging both at the level of cellular changes in an individual tissue and also at the organismal level by extending life span. Our findings point to the possibility that alterations in PGC-1 activity in high-turnover tissues, such as the intestine, may be an important determinant of longevity in mammals.",
    "keywords": ["Antihypertensive Agents"]
}


# VALEUR QUI MARCHE
'''
new_value = {
    "id": "XX-1",
    "title": "The article describes the control of the 2-axis electrohydraulic manipulator by the human-hand motion. To recognition of skeleton points the Kinect sensor was used. In this application the information about coordinates of shoulder, elbow and hand was used to compute of inverse kinematic in manipulator. In investigation the accuracy of control by human's hand motion was tested. The aim of study was to find a new of control method without commonly used joysticks to create human-machine interface.",
    "abstract": "Considering the geographical asymmetric distribution of viral hepatitis A, B and E, having a much higher prevalence in the less developed world, travellers from developed countries are exposed to a considerable and often underestimated risk of hepatitis infection. In fact a significant percentage of viral hepatitis occurring in developed countries is travel related. This results from globalization and increased mobility from tourism, international work, humanitarian and religious missions or other travel related activities. Several studies published in Europe and North America shown that more than 50% of reported cases of hepatitis A are travel related. On the other hand frequent outbreaks of hepatitis A and E in specific geographic areas raise the risk of infection in these restricted zones and that should be clearly identified. Selected aspects related with the distribution of hepatitis A, B and E are reviewed, particularly the situation in Portugal according to the published studies, as well as relevant clinical manifestations and differential diagnosis of viral hepatitis. Basic prevention rules considering enteric transmitted hepatitis (hepatitis A and hepatitis E) and parenteral transmitted (hepatitis B) are reviewed as well as hepatitis A and B immunoprophylaxis. Common clinical situations and daily practice pre travel advice issues are discussed according to WHO/CDC recommendations and the Portuguese National Vaccination Program. Implications from near future availability of a hepatitis E vaccine, a currently in phase 2 trial, are highlighted. Potential indications for travellers to endemic countries like India, Nepal and some regions of China, where up to 30% of sporadic cases of acute viral hepatitis are caused by hepatitis E virus, are considered. Continued epidemiological surveillance for viral hepatitis is essential to recognize and control possible outbreaks, but also to identify new viral hepatitis agents that may emerge as important global health issues.",
    "keywords": ["Antihypertensive Agents"]
}
'''

temp = sorted(list_id.keys())[-1] + 1
list_id[int(temp)] = new_value["id"]

value = [preprocess(new_value["abstract"])]
model, dictionary = updateModel(model, value, dictionary)


# TESTING


test = [preprocess(new_value['abstract'])]
test2 = [dictionary.doc2bow(doc) for doc in test]
result = model.__getitem__(test2)

print(result)
list_authors = []

for i in result[0]:

    res = get_abstract(es, list_id[i[0]])
    print(res)
    exit(0)

    for auth in res:
        list_authors.append({"name": auth["name"], "score": i[1]})

print(list_authors)