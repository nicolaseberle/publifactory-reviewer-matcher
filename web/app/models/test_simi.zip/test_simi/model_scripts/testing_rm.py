from ..model_scripts.preprocess import preprocess
from ..model_scripts.requestsES import get_abstract
from ..model_scripts.requestsES import get_authors_orcid

def getRev(es, value, dictionary, list_id, model):

    test = [preprocess(value)]
    test2 = [dictionary.doc2bow(doc) for doc in test]
    result = model.__getitem__(test2)

    list_authors = []
    y = 0

    for i in result[0]:
        # article = get_abstract(es, list_id[i[0]])
        article = {"doi": "10.21769/bioprotoc.2722"}
        authors_list = get_authors_orcid(article["doi"])
        if get_authors_orcid(article["doi"]):
            for auth in authors_list:
                list_authors.append(
                    {"name": auth["name"], "id": auth["ids"], "affiliation": "soon", "conflit d'intérêt": "soon",
                     "score": i[1], "article": article["title"], "email": "soon", "rs": "soon"})
        else:
            authors_list = article["authors"]
            for auth in authors_list:
                list_authors.append(
                    {"name": auth["name"], "id": auth["ids"], "affiliation": "soon", "conflit d'intérêt": "soon",
                     "score": i[1], "article": article["title"], "email": "soon", "rs": "soon"})
        if y > 5:
            break
        y += 1

    return authors_list
